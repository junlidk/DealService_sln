﻿using DealService.AppService;
using DealService.Data.Parser;
using DealService.Data.Repository;
using DealService.Domain;
using DealService.Domain.Customer;
using DealService.Domain.Deal;
using System.Collections.Generic;

namespace DealService.WCF
{
    public class DealWcfService : IDealWcfService
    {
        private readonly DealApplicationService _appService;

        public DealWcfService()
        {
            //One can use IoC container to inject dependency in WCF service. To be honest, it is my collegue who is used
            //to work with the container. Will figure out how to next time :)
            //The file names can of course get from App.config file.
            string dealCsvFileName = @"..\..\..\DataFiles\deals.txt";
            string customerCsvFileName = @"..\..\..\DataFiles\customers.txt";
            _appService =new DealApplicationService(new CsvDealRepository(new DealCsvFileParser(dealCsvFileName,new DealFactory())),new CsvCustomerRepository(new CustomerCsvFileParser(customerCsvFileName,new CustomerFactory()))  );
        }
        
        public IEnumerable<Deal> GetDealsByCurrency(Currency currency)
        {
            return _appService.GetDealsByCurrency(currency);
        }

        public IEnumerable<Deal> GetDealsByCustomerFullNameOrNameSegment(string nameOrNameSegment)
        {
            return _appService.GetDealsByCustomerFullNameOrNameSegment(nameOrNameSegment);
        }
    }
}
