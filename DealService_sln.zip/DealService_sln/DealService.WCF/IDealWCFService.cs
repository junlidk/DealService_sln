﻿using DealService.Domain;
using DealService.Domain.Deal;
using System.Collections.Generic;
using System.ServiceModel;

namespace DealService.WCF
{
    [ServiceContract]
    public interface IDealWcfService
    {
        [OperationContract]
        IEnumerable<Deal> GetDealsByCurrency(Currency currency);

        [OperationContract]
        IEnumerable<Deal> GetDealsByCustomerFullNameOrNameSegment(string nameOrNameSegment);
    }
}
