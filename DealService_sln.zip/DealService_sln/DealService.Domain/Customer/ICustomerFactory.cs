﻿namespace DealService.Domain.Customer
{
    public interface ICustomerFactory
    {
        Customer Create(int debitorNumber, int branchNumber, string customerName, long seNumber, string language,string country, bool nonResident, Currency currency);
    }
}