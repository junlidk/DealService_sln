using System;
using System.Runtime.Serialization;

namespace DealService.Domain.Customer
{
    [DataContract]
    public class Customer
    {
        [DataMember]
        public int DebitorNumber { get; }
        [DataMember]
        public int BranchNumber { get; }
        [DataMember]
        public string CustomerName { get; }
        [DataMember]
        public long SeNumber { get; }
        [DataMember]
        public string Language { get; }
        [DataMember]
        public string Country { get; }
        [DataMember]
        public bool NonResident { get; }
        [DataMember]
        public Currency Currency { get; }

        public Customer(int debitorNumber, int branchNumber, string customerName, long seNumber, string language, string country, bool nonResident, Currency currency)
        {
            if (string.IsNullOrEmpty(customerName))
            { throw new ArgumentNullException(nameof(customerName)); }

            if(string.IsNullOrEmpty(country))
            { throw new ArgumentNullException(nameof(country));}

            if(currency==null)
            { throw new ArgumentNullException(nameof(currency));}

            DebitorNumber = debitorNumber;
            BranchNumber = branchNumber;
            CustomerName = customerName;
            SeNumber = seNumber;
            Language = language;
            Country = country;
            NonResident = nonResident;
            Currency = currency;
        }


    }
}