﻿namespace DealService.Domain.Customer
{
    public class CustomerFactory : ICustomerFactory
    {
        public Customer Create(int debitorNumber, int branchNumber, string customerName, long seNumber, string language, string country,
            bool nonResident, Currency currency)
        {
            return new Customer(debitorNumber,branchNumber,customerName,seNumber,language,country,nonResident,currency);
        }
    }
}