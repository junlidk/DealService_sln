﻿using System.Collections.Generic;

namespace DealService.Domain.Customer
{
    public interface ICustomerRepository
    {
        ICollection<Customer> GetCustomerByFullNameOrNameSegment(string nameOrNameSegment);
    }
}
