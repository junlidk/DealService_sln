﻿using System;

namespace DealService.Domain.Deal
{
    public interface IDealFactory
    {
        Deal Create(string loanNumber, int branchNumber, int debtorNumber, Currency currency, decimal amount, DateTime creationDate, DateTime dueDate, decimal interbankRate, decimal marginalRate);
    }
}
