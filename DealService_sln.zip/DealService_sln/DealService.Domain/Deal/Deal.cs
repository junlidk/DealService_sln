﻿using System;
using System.Runtime.Serialization;

namespace DealService.Domain.Deal
{
    [DataContract]
    public class Deal 
    {
        [DataMember]
        public string LoanNumber { get; }
        [DataMember]
        public int BranchNumber { get; }
        [DataMember]
        public int DebtorNumber { get; }
        [DataMember]
        public Currency Currency { get; }
        [DataMember]
        public decimal Amount { get; }
        [DataMember]
        public DateTime CreationDate { get; }
        [DataMember]
        public DateTime DueDate { get; }
        [DataMember]
        public decimal InterbankRate { get; }
        [DataMember]
        public decimal MarginalRate { get; }

        public Deal(string loanNumber, int branchNumber, int debtorNumber, Currency currency, decimal amount, DateTime creationDate, DateTime dueDate, decimal interbankRate, decimal marginalRate)
        {
            if (string.IsNullOrEmpty(loanNumber))
            {
                throw new ArgumentNullException(loanNumber);
            }

            LoanNumber = loanNumber;
            BranchNumber = branchNumber;
            DebtorNumber = debtorNumber;
            Currency = currency;
            Amount = amount;
            CreationDate = creationDate;
            DueDate = dueDate;
            InterbankRate = interbankRate;
            MarginalRate = marginalRate;
        }
    }
}