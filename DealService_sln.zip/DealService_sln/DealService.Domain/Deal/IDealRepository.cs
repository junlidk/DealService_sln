﻿using System.Collections.Generic;

namespace DealService.Domain.Deal
{
    public interface IDealRepository
    {
        IEnumerable<Deal> GetDealsByCurrency(Currency currency);
        IEnumerable<Deal> GetDealsByDebtorNumber(int debtorNumber);
    }
}
