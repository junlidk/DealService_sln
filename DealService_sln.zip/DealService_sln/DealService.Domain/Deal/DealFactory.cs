using System;

namespace DealService.Domain.Deal
{
    public class DealFactory : IDealFactory
    {
        public Deal Create(string loanNumber, int branchNumber, int debtorNumber, Currency currency, decimal amount,
            DateTime creationDate, DateTime dueDate, decimal interbankRate, decimal marginalRate)
        {
            return new Deal(loanNumber,branchNumber,debtorNumber,currency,amount,creationDate,dueDate,interbankRate,marginalRate);
        }
    }
}