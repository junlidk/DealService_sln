﻿using System;
using System.Runtime.Serialization;

namespace DealService.Domain
{
    [DataContract]
    public class Currency
    {
        [DataMember]
        public string Name { get; private set; }

        public Currency(string currency)
        {
            if (IsValid(currency))
            { Name = currency; }
            else
            { throw new ArgumentException($"Invalid currency '{currency}'."); }
        }

        private bool IsValid(string currency)
        {
            //Validation logic, if any
            return true;
        }
    }
}
