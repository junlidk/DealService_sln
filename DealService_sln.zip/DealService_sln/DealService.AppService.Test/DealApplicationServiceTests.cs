﻿using DealService.Domain;
using DealService.Domain.Customer;
using DealService.Domain.Deal;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace DealService.AppService.Test
{
    public class DealApplicationServiceTests
    {
        [Fact]
        public void GetDealsByCurrency_Calls_DealRepository_When_Currency_Is_Not_Null()
        {
            //Arrange
            var dealRepository = new Mock<IDealRepository>();
            var customerRepository = new Mock<ICustomerRepository>();
            var sut = new DealApplicationService(dealRepository.Object, customerRepository.Object);
            //Act
            sut.GetDealsByCurrency(new Mock<Currency>("SEK").Object);
            //Assert
            dealRepository.Verify(d => d.GetDealsByCurrency(It.IsAny<Currency>()), Times.Once);
        }

        [Fact]
        public void GetDealsByCurrency_Throws_Exception_When_Currency_Is_Null()
        {
            //Arrange
            var dealRepository = new Mock<IDealRepository>();
            var customerRepository = new Mock<ICustomerRepository>();
            var sut = new DealApplicationService(dealRepository.Object, customerRepository.Object);
            //Assert
            Assert.ThrowsAny<Exception>(() => sut.GetDealsByCurrency(null));
        }

        [Fact]
        public void GetDealsByCustomerFullNameOrNameSegment_Throws_Exception_If_More_Than_One_Customer_Found()
        {
            //Arrange
            var dealRepository = new Mock<IDealRepository>();
            var customerRepository = new Mock<ICustomerRepository>();
            var customer1 = new Mock<Customer>(1001, 1111, "ACME", 1111111, "S", "SE", true, new Mock<Currency>("DKK").Object);
            var customer2 = new Mock<Customer>(1002, 1111, "Digital Solution", 1111111, "S", "SE", true, new Mock<Currency>("DKK").Object);
            var customerList = new List<Customer>() { customer1.Object, customer2.Object };
            customerRepository.Setup(c => c.GetCustomerByFullNameOrNameSegment(It.IsAny<string>()))
                .Returns(customerList);
            var sut = new DealApplicationService(dealRepository.Object, customerRepository.Object);
            //Assert
            Assert.ThrowsAny<Exception>(() => sut.GetDealsByCustomerFullNameOrNameSegment("Fack name"));
        }

        [Fact]
        public void GetDealsByCustomerFullNameOrNameSegment_Returns_Empty_List_If_No_Customer_Found()
        {
            //Arrange
            var dealRepository = new Mock<IDealRepository>();
            var customerRepository = new Mock<ICustomerRepository>();
            var customerList = new List<Customer>();
            customerRepository.Setup(c => c.GetCustomerByFullNameOrNameSegment(It.IsAny<string>()))
                .Returns(customerList);
            var sut = new DealApplicationService(dealRepository.Object, customerRepository.Object);
            //Act
            var deals = sut.GetDealsByCustomerFullNameOrNameSegment("Fack name");
            //Assert
            Assert.True(!deals.Any());
        }

        [Fact]
        public void GetDealsByCustomerFullNameOrNameSegment_Calls_DealRepository_If_One_Customer_Found()
        {
            //Arrange
            var dealRepository = new Mock<IDealRepository>();
            var customerRepository = new Mock<ICustomerRepository>();
            var customer1 = new Mock<Customer>(1001, 1111, "ACME", 1111111, "S", "SE", true, new Mock<Currency>("DKK").Object);
            var customerList = new List<Customer>() {customer1.Object};
            customerRepository.Setup(c => c.GetCustomerByFullNameOrNameSegment(It.IsAny<string>()))
                .Returns(customerList);
            var sut = new DealApplicationService(dealRepository.Object, customerRepository.Object);
            //Act
            sut.GetDealsByCustomerFullNameOrNameSegment("Fack name");
            //Assert
            dealRepository.Verify(d => d.GetDealsByDebtorNumber(It.IsAny<int>()), Times.Once);
        }
    }
}
