﻿using DealService.Data.Parser;
using DealService.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using DealService.Domain.Deal;

namespace DealService.Data.Repository
{
    public class CsvDealRepository : IDealRepository
    {
        private readonly CsvFileParser<Deal> _csvParser;
        private ICollection<Deal> _allDeals;
        public CsvDealRepository(CsvFileParser<Deal> csvParser)
        {
            _csvParser = csvParser;
        }

        public IEnumerable<Deal> GetDealsByCurrency(Currency currency)
        {
            if (currency == null)
            { throw new ArgumentNullException(nameof(currency)); }

            GetAllDeals();
            return _allDeals.Where(c => c.Currency.Name.Equals(currency.Name, StringComparison.InvariantCultureIgnoreCase)).ToList();
        }

        public IEnumerable<Deal> GetDealsByDebtorNumber(int debtorNumber)
        {
            GetAllDeals();
            return _allDeals.Where(d => d.DebtorNumber == debtorNumber).ToList();
        }

        private void GetAllDeals()
        {
            if (_allDeals == null)
            {
                _allDeals = _csvParser.Parse();
            }
        }
    }
}
