﻿using System;
using System.Collections.Generic;
using System.Linq;
using DealService.Data.Parser;
using DealService.Data.Extension;
using DealService.Domain.Customer;

namespace DealService.Data.Repository
{
    public class CsvCustomerRepository : ICustomerRepository
    {
        private readonly ICsvFileParser<Customer> _csvParser;

        private ICollection<Customer> _allCustomers;

        public CsvCustomerRepository(ICsvFileParser<Customer> csvParser)
        {
            _csvParser = csvParser;
        }

        public ICollection<Customer> GetCustomerByFullNameOrNameSegment(string nameOrNameSegment)
        {
            if (string.IsNullOrEmpty(nameOrNameSegment))
            { throw new ArgumentNullException(nameof(nameOrNameSegment)); }

            GetAllCustomers();
            return _allCustomers.Where(c => c.CustomerName.Contains(nameOrNameSegment,StringComparison.OrdinalIgnoreCase)).ToList();
        }

        private void GetAllCustomers()
        {
            if (_allCustomers == null)
            {
                _allCustomers = _csvParser.Parse();
            }
        }
    }
}
