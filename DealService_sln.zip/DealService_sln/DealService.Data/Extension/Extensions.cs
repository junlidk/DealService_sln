﻿using System;

namespace DealService.Data.Extension
{
    public static class Extensions
    {
        public static int ToInt(this string input)
        {
            ValidateInputString(input);
            int outPut;
            if (!int.TryParse(input, out outPut))
            {
                throw new Exception($"input string '{input}' could not be parsed to int.");
            }
            return outPut;
        }

        public static long ToLong(this string input)
        {
            ValidateInputString(input);
            long outPut;
            if (!long.TryParse(input, out outPut))
            {
                throw new Exception($"input string '{input}' could not be parsed to int.");
            }
            return outPut;
        }

        public static decimal ToDecimal(this string input)
        {
            ValidateInputString(input);
            decimal outPut;
            if (!decimal.TryParse(input, out outPut))
            {
                throw new Exception($"input string '{input}' could not be parsed to decimal.");
            }
            return outPut;
        }

        public static DateTime ToDateTime(this string input)
        {
            ValidateInputString(input);
            DateTime outPut;
            if (!DateTime.TryParse(input, out outPut))
            {
                throw new Exception($"input string '{input}' could not be parsed to DateTime.");
            }
            return outPut;
        }

        public static bool ToBoolean(this string input)
        {
            ValidateInputString(input);
            if (!input.Equals(Constants.TrueFalse.True)&&!input.Equals(Constants.TrueFalse.False))
            {
                throw new Exception($"input string '{input}' could not be parsed to bool.");
            }
            var outPut = input.Equals(Constants.TrueFalse.True);
            return outPut;
        }

        public static bool Contains(this string input, string toCheck, StringComparison comp)
        {
            ValidateInputString(input);
            return input.IndexOf(toCheck, comp) >= 0;
        }


        private static void ValidateInputString(string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                throw new ArgumentNullException(nameof(input));
            }
        }
    }
}
