using DealService.Data.Extension;
using DealService.Domain;
using DealService.Domain.Deal;
using System;

namespace DealService.Data.Parser
{
    public class DealCsvFileParser : CsvFileParser<Deal>
    {
        private readonly IDealFactory _dealFactory;

        public DealCsvFileParser(string fileName, IDealFactory dealFactory) : base(fileName)
        {
            if (dealFactory == null)
            { throw new ArgumentNullException(nameof(dealFactory)); }

            _dealFactory = dealFactory;
        }

        protected override Deal GetDomainObject(string[] values)
        {
            if (values == null)
            {
                throw new ArgumentNullException(nameof(values));
            }
            if (values.Length != Constants.DealCsvColumnIndex.MaxColumnIndex)
            {
                throw new ArgumentException($"Can not parse input array to Deal object. Expected array length '{Constants.DealCsvColumnIndex.MaxColumnIndex}', but it was {values.Length}",nameof(values));
            }

            var loanNumber = values[Constants.DealCsvColumnIndex.LoanNumber];
            var branchNumber = values[Constants.DealCsvColumnIndex.BranchNumber].ToInt();
            var debtorNumber = values[Constants.DealCsvColumnIndex.DebtorNumber].ToInt();
            var currencyName = values[Constants.DealCsvColumnIndex.Currency].Trim();
            var currency = new Currency(currencyName); //Currency is simple class, so I just initialized directly here.Not 100% dependency injection!
            var amount = values[Constants.DealCsvColumnIndex.Amount].ToDecimal();
            var creationDate = values[Constants.DealCsvColumnIndex.CreationDate].ToDateTime();
            var dueDate = values[Constants.DealCsvColumnIndex.DueDate].ToDateTime();
            var interbankRate = values[Constants.DealCsvColumnIndex.InterbankRate].ToDecimal();
            var marginalRate = values[Constants.DealCsvColumnIndex.MarginalRate].ToDecimal();
            return _dealFactory.Create(loanNumber, branchNumber, debtorNumber, currency, amount, creationDate, dueDate,interbankRate, marginalRate);
        }
    }
}