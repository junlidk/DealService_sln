﻿using System.Collections.Generic;

namespace DealService.Data.Parser
{
    public interface ICsvFileParser<T>
    {
        ICollection<T> Parse();
    }
}