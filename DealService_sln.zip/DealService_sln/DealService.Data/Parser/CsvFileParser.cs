using System.Collections.Generic;
using System.IO;

namespace DealService.Data.Parser
{
    public abstract class CsvFileParser<T> : ICsvFileParser<T>
    {
        private readonly string _fileName;
        protected abstract T GetDomainObject(string[] values);
        protected CsvFileParser(string fileName)
        {
            if (IsValidFileName(fileName))
            {
                _fileName = fileName;
            }
        }
        public ICollection<T> Parse()
        {
            var domainObjects = new List<T>();
            var lines = File.ReadAllLines(_fileName);

            if (lines.Length <= 1)
            {
                return domainObjects;
            }

            for (var i = 1; i < lines.Length; i++)
            {
                var values = lines[i].Split(';');
                var domainObject = GetDomainObject(values);
                domainObjects.Add(domainObject);
            }

            return domainObjects;
        }
        private static bool IsValidFileName(string fileName)
        {
            if (!File.Exists(fileName))
            { throw new FileNotFoundException($"file '{fileName}' is not found."); }
            return true;
        }
    }
}