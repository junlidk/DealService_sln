using DealService.Data.Extension;
using System;
using DealService.Domain.Customer;
using DealService.Domain;

namespace DealService.Data.Parser
{
    public class CustomerCsvFileParser: CsvFileParser<Customer>
    {
        private readonly ICustomerFactory _customerFactory;

        public CustomerCsvFileParser(string fileName,ICustomerFactory customerFactory) : base(fileName)
        {
            if (customerFactory == null)
            {
                throw new ArgumentNullException(nameof(customerFactory));
            }
            _customerFactory = customerFactory;
        }

        protected override Customer GetDomainObject(string[] values)
        {
            if (values == null)
            {
                throw new ArgumentNullException(nameof(values));
            }
            if (values.Length != Constants.CustomerCsvColumnIndex.MaxColumnIndex)
            {
                throw new ArgumentException($"Can not parse input array to Customer object. Expected array length '{Constants.CustomerCsvColumnIndex.MaxColumnIndex}', but it was {values.Length}", nameof(values));
            }

            var debitorNumber=values[Constants.CustomerCsvColumnIndex.DebtorNumber].ToInt();
            var branchNumber = values[Constants.CustomerCsvColumnIndex.BranchNumber].ToInt();
            var customerName=values[Constants.CustomerCsvColumnIndex.CustomerName];
            var seNumber=values[Constants.CustomerCsvColumnIndex.SeNumber].ToLong();
            var language=values[Constants.CustomerCsvColumnIndex.Language];
            var country=values[Constants.CustomerCsvColumnIndex.Country];
            var nonResident=values[Constants.CustomerCsvColumnIndex.NonResident].ToBoolean();
            var currencyName = values[Constants.CustomerCsvColumnIndex.Currency];
            var currency=new Currency(currencyName);// Currency is simple class, so I just initialized directly here. Not 100% dependency injection!
            return _customerFactory.Create(debitorNumber, branchNumber, customerName, seNumber, language, country,nonResident, currency);
        }
    }
}