﻿namespace DealService.Data
{
    internal static class Constants
    {
        public static class CustomerCsvColumnIndex
        {
            public static int MaxColumnIndex = 8;
            public static int BranchNumber = 0;
            public static int DebtorNumber = 1;
            public static int CustomerName = 2;
            public static int SeNumber = 3;
            public static int Language = 4;
            public static int Country = 5;
            public static int NonResident = 6;
            public static int Currency = 7;
        }

        public static class DealCsvColumnIndex
        {
            public static int MaxColumnIndex = 9;
            public static int LoanNumber = 0;
            public static int BranchNumber = 1;
            public static int DebtorNumber = 2;
            public static int Currency = 3;
            public static int Amount = 4;
            public static int CreationDate = 5;
            public static int DueDate = 6;
            public static int InterbankRate = 7;
            public static int MarginalRate = 8;
        }

        public static class TrueFalse
        {
            public  const string True = "J";
            public  const string False="N";
        }
    }
}
