﻿using System;
using System.Linq;
using DealService.AppService;
using DealService.Data.Parser;
using DealService.Data.Repository;
using DealService.Domain;
using DealService.Domain.Customer;
using DealService.Domain.Deal;
using Xunit;

namespace DealService.Integration.Test
{
    public class DealApplicationServiceTests
    {
        [Fact]
        public void GetDealsByCurrency_Returns_Deals_When_Currency_Exists_In_DataSource()
        {
            //Arrange
            var sut = InitializeAppService();
            var currency=new Currency("DKK");
            //Act
            var deals=sut.GetDealsByCurrency(currency);
            //Assert
            Assert.Equal(3,deals.Count());
        }

        [Fact]
        public void GetDealsByCurrency_Returns_Empty_Deal_Collection_When_Currency_Does_Not_Exist_In_DataSource()
        {
            //Arrange
            var sut = InitializeAppService();
            var currency = new Currency("CNY");
            //Act
            var deals = sut.GetDealsByCurrency(currency);
            //Assert
            Assert.True(!deals.Any());
        }

        [Fact]
        public void GetDealsByCustomerFullNameOrNameSegment_Returns_Deals_With_Customer_FullName()
        {
            //Arrange
            var sut = InitializeAppService();
            //Act
            var deals = sut.GetDealsByCustomerFullNameOrNameSegment("ACME Incorporated");
            //Assert
            Assert.Equal(1,deals.Count());
        }
        [Fact]
        public void GetDealsByCustomerFullNameOrNameSegment_Returns_Deals_With_Customer_Name_Segment()
        {
            //Arrange
            var sut = InitializeAppService();
            //Act
            var deals = sut.GetDealsByCustomerFullNameOrNameSegment("CME");
            //Assert
            Assert.Equal(1, deals.Count());
        }

        [Fact]
        public void GetDealsByCustomerFullNameOrNameSegment_Returns_Deals_Case_Insensitive()
        {
            //Arrange
            var sut = InitializeAppService();
            //Act
            var deals = sut.GetDealsByCustomerFullNameOrNameSegment("cme");
            //Assert
            Assert.Equal(1, deals.Count());
        }

        [Fact]
        public void GetDealsByCustomerFullNameOrNameSegment_Returns_Deals_When_There_Are_Several_Deals_For_One_Customer()
        {
            //Arrange
            var sut = InitializeAppService();
            //Act
            var deals = sut.GetDealsByCustomerFullNameOrNameSegment("Larsen Insurance");
            //Assert
            Assert.Equal(3, deals.Count());
        }

        [Fact]
        public void GetDealsByCustomerFullNameOrNameSegment_Returns_Empty_Deal_Collection_When_Customer_Not_Found()
        {
            //Arrange
            var sut = InitializeAppService();
            //Act
            var deals = sut.GetDealsByCustomerFullNameOrNameSegment("Fack name");
            //Assert
            Assert.True(!deals.Any());
        }

        [Fact]
        public void GetDealsByCustomerFullNameOrNameSegment_Throws_Exception_If_More_Than_One_Customer_Found()
        {
            //Arrange
            var sut = InitializeAppService();
            //Assert
            Assert.ThrowsAny<Exception>(()=>sut.GetDealsByCustomerFullNameOrNameSegment("Larsen"));
         }

        private static DealApplicationService InitializeAppService()
        {
            string dealCsvFileName = @"..\..\Data\deals.txt";
            string customerCsvFileName = @"..\..\Data\customers.txt";
            var appService =
                new DealApplicationService(new CsvDealRepository(new DealCsvFileParser(dealCsvFileName, new DealFactory())),
                    new CsvCustomerRepository(new CustomerCsvFileParser(customerCsvFileName, new CustomerFactory())));
            return appService;
        }
    }
}
