﻿using System.Collections.Generic;
using System.Linq;
using DealService.Data.Parser;
using DealService.Data.Repository;
using DealService.Domain;
using DealService.Domain.Customer;
using Moq;
using Xunit;

namespace DealService.Data.Test
{
    public class CsvCustomerRepositoryTests
    {
        [Fact]
        public void GetCustomerByFullNameOrNameSegment_Returns_Customer_Collection_If_Customer_Found()
        {
            //Arrange
            var csvParser = GetMockedCsvParser();
            var sut=new CsvCustomerRepository(csvParser.Object);
            //Act
            var matchedCustomers=sut.GetCustomerByFullNameOrNameSegment("ACME");
            //Assert
            Assert.Equal(1,matchedCustomers.Count);
        }

        [Fact]
        public void GetCustomerByFullNameOrNameSegment_Returns_Empty_Customer_Collection_If_Customer_Not_Found()
        {
            //Arrange
            var csvParser = GetMockedCsvParser();
            //Act
            var sut = new CsvCustomerRepository(csvParser.Object);
            var matchedCustomers = sut.GetCustomerByFullNameOrNameSegment("Fack name");
            //Assert
            Assert.True(!matchedCustomers.Any());
        }

        private static Mock<ICsvFileParser<Customer>> GetMockedCsvParser()
        {
            var csvParser = new Mock<ICsvFileParser<Customer>>();
            var currency = new Mock<Currency>("SEK");
           
            var customer1 = new Mock<Customer>(1001, 1111, "ACME", 1111111, "S", "SE", true, currency.Object);
            var customer2 = new Mock<Customer>(1002, 1111, "Digital Solutions", 1111111, "D", "DK", false, currency.Object);
            var customers = new List<Customer>() {customer1.Object,customer2.Object};
           
            csvParser.Setup(p => p.Parse()).Returns(customers);
            return csvParser;
        }
    }
}
