﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DealService.Data.Test
{
    public class CsvDealRepositoryTests
    {
        //Code will be similar to CsvCustomerRepositoryTests class. 
        //Please see CsvCustomerRepositoryTests class as example.
    }
}
