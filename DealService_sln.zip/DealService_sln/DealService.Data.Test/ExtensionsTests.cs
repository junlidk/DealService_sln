﻿using System;
using Xunit;
using DealService.Data.Extension;
namespace DealService.Data.Test
{
    public class ExtensionsTests
    {
        [Fact]
        public void ToInt_Converts_String_To_Int()
        {
            //Arrange
            var input = "212";
            //Act
            var output=input.ToInt();
            //Assert
            Assert.Equal(212,output);
        }

        [Fact]
        public void ToInt_Throws_Exception_If_Input_String_Is_Not_Int()
        {
            //Arrange
            var input = "y212";
            //Assert
            Assert.ThrowsAny<Exception>(()=>input.ToInt());
        }

        [Fact]
        public void Contains_Returns_True_If_Input_String_Contains_String_To_Check()
        {
            //Arrange
            var input = "HelloWorld";
            var stringToCheck = "Hello";
            //Act
            var result = input.Contains(stringToCheck,StringComparison.OrdinalIgnoreCase);
            //Assert
            Assert.True(result);
        }

        [Fact]
        public void Contains_Returns_True_If_Input_String_Contains_String_To_Check_Ignore_Case()
        {
            //Arrange
            var input = "HelloWorld";
            var stringToCheck = "woR";
            //Act
            var result = input.Contains(stringToCheck,StringComparison.OrdinalIgnoreCase);
            //Assert
            Assert.True(result);
        }
    }
}
