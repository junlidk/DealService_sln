﻿using DealService.Domain.Customer;
using DealService.Domain.Deal;
using DealService.Domain;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DealService.AppService
{
    public class DealApplicationService
    {
        private readonly IDealRepository _dealRepository;
        private readonly ICustomerRepository _customerRepository;

        public DealApplicationService(IDealRepository dealRepository, ICustomerRepository customerRepository)
        {
            if (dealRepository == null)
            {
                throw new ArgumentNullException(nameof(dealRepository));
            }
            if (customerRepository == null)
            {
                throw new ArgumentNullException(nameof(customerRepository));
            }
            _dealRepository = dealRepository;
            _customerRepository = customerRepository;
        }

        public IEnumerable<Deal> GetDealsByCurrency(Currency currency)
        {
            if (currency == null)
            {
                throw new ArgumentNullException(nameof(currency));
            }
            return _dealRepository.GetDealsByCurrency(currency);
        }

        public IEnumerable<Deal> GetDealsByCustomerFullNameOrNameSegment(string nameOrNameSegment)
        {
            if (string.IsNullOrEmpty(nameOrNameSegment))
            { throw new ArgumentNullException(nameof(nameOrNameSegment)); }

            var customers = _customerRepository.GetCustomerByFullNameOrNameSegment(nameOrNameSegment);

            var noCustomerFound = customers == null || !customers.Any();
            var moreThanOneCustomerFound = customers != null && customers.Count() > 1;

            if (noCustomerFound)
            {
                return new List<Deal>();
            }
            if (moreThanOneCustomerFound)
            {
                throw new Exception($"There are more than one customer found with the input customer name or name segment '{nameOrNameSegment}'");
            }

            var customer = customers.Single();
            return _dealRepository.GetDealsByDebtorNumber(customer.DebitorNumber);
        }
    }
}
