﻿using Moq;
using System;
using Xunit;

namespace DealService.Domain.Test
{
    public class DealTests
    {
        [Fact]
        public void Constructor_Initializes_New_Customer_Instance()
        {
            //Arrange
            var sut = new Deal.Deal("1001A", 1111, 1001, new Mock<Currency>("SEK").Object, 100000, new DateTime(2013, 9, 19),
                new DateTime(2015, 11, 11), 0.128m, 2);
            //Assert
            Assert.NotNull(sut);
        }

        [Fact]
        public void Constructor_Throws_ArgumentNullException_If_LoanNumber_Is_Null_Or_Empty()
        {
            Assert.ThrowsAny<ArgumentNullException>(
                () =>
                    new Deal.Deal(string.Empty, 1111, 1001, new Mock<Currency>("SEK").Object, 100000,
                        new DateTime(2013, 9, 19),
                        new DateTime(2015, 11, 11), 0.128m, 2));
        }
    }
}
