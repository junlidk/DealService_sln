﻿using Moq;
using System;
using System.Collections.Generic;
using Xunit;

namespace DealService.Domain.Test
{
    public class CustomerTests
    {
        [Theory]
        [MemberData("InvalidArguments")]
        public void Constructor_Throws_ArgumentNullException_If_Any_Invalid_Argument(int debtorNumber,int branchNumber, string customerName, long seNumber, string language, string country, bool nonResident, Currency currency)
        {
            Assert.ThrowsAny<ArgumentNullException>(
                () =>
                    new Customer.Customer(debtorNumber, branchNumber, customerName, seNumber, language, country,
                        nonResident, currency));
        }

        [Fact]
        public void Constructor_Initialized_New_Customer_Instance()
        {
            var currency = new Mock<Currency>("SEK");
            var sut = new Customer.Customer(1001, 1111, "ACME", 1111111, "S", "SE", true, currency.Object);
            Assert.NotNull(sut);
        }
        public static IEnumerable<object[]> InvalidArguments
        {
            get
            {
                return new[]
                {
                    new object[]{1001,1111, null,1111111,"S","SE",true,new Currency("SEK"), },
                    new object[]{1001,1111, "ACME",1111111,"S",null,true,new Currency("SEK"), },
                    new object[]{1001,1111, "ACME",1111111,"S","SE",true,null},
                };
            }
        } 
    }
}
